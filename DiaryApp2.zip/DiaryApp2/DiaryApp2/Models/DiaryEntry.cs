﻿using System.ComponentModel.DataAnnotations;

namespace DiaryApp2.Models
   
{
    public class DiaryEntry
    {
        //Each of these properties will be a column inside the database
        public int Id { get; set; }
        //Says that this entry cannot be nulled
        [Required(ErrorMessage ="Please enter a title!")]
       [StringLength(100,MinimumLength =3, 
          ErrorMessage ="Title must be between 3 and 100 characters")]
        
        public string Title { get; set; } = string.Empty;
        [Required]
        public string Content { get; set; } = string.Empty;
        [Required]
        public DateTime Created { get; set; } = DateTime.Now;
    }
}
