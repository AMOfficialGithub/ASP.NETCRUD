﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace DiaryApp2.Migrations
{
    /// <inheritdoc />
    public partial class AddedSeedingDataDiaryEntry : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "Diary2Entries",
                columns: new[] { "Id", "Content", "Created", "Title" },
                values: new object[,]
                {
                    { 1, "Went hiking with Joe!", new DateTime(2024, 9, 17, 14, 10, 9, 462, DateTimeKind.Local).AddTicks(2126), "Went Hiking" },
                    { 2, "Went shopping with Joe!", new DateTime(2024, 9, 17, 14, 10, 9, 462, DateTimeKind.Local).AddTicks(2432), "Went Shopping" },
                    { 3, "Went Swimming with Joe!", new DateTime(2024, 9, 17, 14, 10, 9, 462, DateTimeKind.Local).AddTicks(2436), "Went Swimming" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Diary2Entries",
                keyColumn: "Id",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Diary2Entries",
                keyColumn: "Id",
                keyValue: 2);

            migrationBuilder.DeleteData(
                table: "Diary2Entries",
                keyColumn: "Id",
                keyValue: 3);
        }
    }
}
