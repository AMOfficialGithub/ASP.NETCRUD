﻿using DiaryApp2.Data;
using DiaryApp2.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using System.Reflection.Metadata.Ecma335;

namespace DiaryApp2.Controllers
{
    public class DiaryEntriesController : Controller
    {
        private readonly ApplicationDbContext _db;

        //Injecting the ApplictionDbContext
        public DiaryEntriesController(ApplicationDbContext db)
        {
            _db = db;
        }
        public IActionResult Index()
        {
            List<DiaryEntry> objDiaryEntryList = _db.Diary2Entries.ToList();
            return View(objDiaryEntryList);
        }

        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(DiaryEntry obj)
        {
            //An additional layer of checking if data entered is correct
            if(obj == null && obj.Title.Length < 3)
            {
                ModelState.AddModelError("Title", "Title too short");
            }
            if(ModelState.IsValid)
            {
                _db.Diary2Entries.Add(obj); //Adds new diary entry
                _db.SaveChanges(); //saves the diary changes to database
                return RedirectToAction("Index");
            }
            return View(obj);
        }
        [HttpGet]
        public IActionResult Edit(int? id)
        {
            if(id == null || id == 0)
            {
                return NotFound();
            }
            DiaryEntry? diaryEntry = _db.Diary2Entries.Find(id);
            if(diaryEntry == null)
            {
                return NotFound();
            }
            return View(diaryEntry);
        }

        [HttpPost]
        public IActionResult Edit(DiaryEntry obj)
        {
            //An additional layer of checking if data entered is correct
            if (obj == null && obj.Title.Length < 3)
            {
                ModelState.AddModelError("Title", "Title too short");
            }
            if (ModelState.IsValid)
            {
                _db.Diary2Entries.Update(obj); //Updates the diary entry in the database
                _db.SaveChanges(); //saves the diary changes to database
                return RedirectToAction("Index");
            }
            return View(obj);
        }

        [HttpGet]
        public IActionResult Delete(int? id)
        {
            if (id == null || id == 0)
            {
                return NotFound();
            }
            DiaryEntry? diaryEntry = _db.Diary2Entries.Find(id);
            if (diaryEntry == null)
            {
                return NotFound();
            }
            return View(diaryEntry);
        }

        [HttpPost]
        public IActionResult Delete(DiaryEntry obj)
        {
            
            
                _db.Diary2Entries.Remove(obj); //Remove the diary entry in the database
                _db.SaveChanges(); //saves the diary changes to database
                return RedirectToAction("Index");
            
          
        }
    }
}
