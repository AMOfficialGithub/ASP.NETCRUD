using DiaryApp2.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace DiaryApp2.Controllers
{
    public class HomeController : Controller
    {
        //Passing ILogger to home controller.
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        //Will return a result for us, which will return a View();
        //This returns an Index View in the View folder, Home Folder(must be named the same as
        //the HomeController, and Index.cshtml
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult MyPage()
        {
            return View();
        }
        //This returns a Privacy View
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]

        //Inside of views is a Shared folder. Returns the error with additional information.
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
